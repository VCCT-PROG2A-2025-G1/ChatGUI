﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberChatbotGUI.Logs
{
    public static class Logs
    {
        private static readonly List<string> logEntries = new List<string>();

        public static void Add(string message)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            logEntries.Insert(0, $"{timestamp} - {message}");

            if (logEntries.Count > 100)
            {
                logEntries.RemoveAt(logEntries.Count - 1);
            }
        }

        public static List<string> GetRecentLogs(int count = 10)
        {
            return logEntries.Take(count).ToList();
        }

        public static List<string> GetAllLogs()
        {
            return new List<string>(logEntries);
        }

        public static void Clear()
        {
            logEntries.Clear();
        }
    }
}
