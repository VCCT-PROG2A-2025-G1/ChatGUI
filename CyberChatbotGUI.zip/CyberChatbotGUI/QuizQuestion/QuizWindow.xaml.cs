﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace CyberChatbotGUI.QuizQuestion
{
    public partial class QuizWindow : Window
    {
        private List<QuizQuestion> questions;
        private int currentQuestionIndex = 0;
        private int score = 0;
        private bool answered = false;

        public QuizWindow()
        {
            InitializeComponent();
            LoadQuizQuestions();
            DisplayCurrentQuestion();
        }

        private void LoadQuizQuestions()
        {
            questions = new List<QuizQuestion>
            {
                new QuizQuestion {
                    QuestionText = "What should you do if you receive an email asking for your password?",
                    Options = new[] { "A) Reply with your password", "B) Delete the email", "C) Report the email as phishing", "D) Ignore it" },
                    CorrectIndex = 2,
                    Explanation = "Correct! Reporting phishing emails helps protect you and others."
                },
                new QuizQuestion {
                    QuestionText = "True or False: You should use the same password for all your accounts.",
                    Options = new[] { "True", "False" },
                    CorrectIndex = 1,
                    Explanation = "Correct! Using different passwords helps limit the damage if one account is hacked."
                },
                new QuizQuestion {
                    QuestionText = "Which of the following is considered a strong password?",
                    Options = new[] { "123456", "qwerty", "P@ssw0rd!2025", "mydogname" },
                    CorrectIndex = 2,
                    Explanation = "Correct! Strong passwords include upper/lowercase, symbols, and numbers."
                },
                new QuizQuestion {
                    QuestionText = "What is phishing?",
                    Options = new[] { "A security update", "A type of malware", "A scam to trick you into giving info", "A software tool" },
                    CorrectIndex = 2,
                    Explanation = "Correct! Phishing is a scam where attackers pose as trustworthy sources."
                },
                new QuizQuestion {
                    QuestionText = "True or False: HTTPS means the website is safe.",
                    Options = new[] { "True", "False" },
                    CorrectIndex = 1,
                    Explanation = "Correct! HTTPS encrypts traffic, but doesn’t guarantee the site is trustworthy."
                },
                new QuizQuestion {
                    QuestionText = "What is Two-Factor Authentication (2FA)?",
                    Options = new[] { "A firewall", "A password manager", "An extra layer of login security", "A type of virus" },
                    CorrectIndex = 2,
                    Explanation = "Correct! 2FA uses a second step like an SMS code to protect your account."
                },
                new QuizQuestion {
                    QuestionText = "Which of these is a common sign of a phishing email?",
                    Options = new[] { "Spelling errors", "Urgent requests", "Unknown attachments", "All of the above" },
                    CorrectIndex = 3,
                    Explanation = "Correct! All of these are common phishing warning signs."
                },
                new QuizQuestion {
                    QuestionText = "True or False: Software updates help protect your device from hackers.",
                    Options = new[] { "True", "False" },
                    CorrectIndex = 0,
                    Explanation = "Correct! Updates patch security flaws that attackers can exploit."
                },
                new QuizQuestion {
                    QuestionText = "What should you do before clicking on a link in an email?",
                    Options = new[] { "Click fast", "Hover to see the URL", "Forward to friends", "Ignore all links" },
                    CorrectIndex = 1,
                    Explanation = "Correct! Always check the link’s real destination by hovering first."
                },
                new QuizQuestion {
                    QuestionText = "Which of the following is safest to use on public Wi-Fi?",
                    Options = new[] { "Online banking", "Shopping with your card", "VPN connection", "Free movie sites" },
                    CorrectIndex = 2,
                    Explanation = "Correct! A VPN encrypts your data on unsafe public networks."
                }
            };
        }

        private void DisplayCurrentQuestion()
        {
            if (currentQuestionIndex >= questions.Count)
            {
                MessageBox.Show($"✅ Quiz complete! Your score: {score}/{questions.Count}\n\n" +
                                (score >= 8 ? "🎉 Great job! You're a cybersecurity pro!" : "📚 Keep learning to stay safe online!"),
                                "Quiz Result", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
                return;
            }

            var q = questions[currentQuestionIndex];
            QuestionTextBlock.Text = q.QuestionText;
            OptionsListBox.ItemsSource = q.Options;
            OptionsListBox.SelectedIndex = -1;
            FeedbackTextBlock.Text = "";
            answered = false;
        }

        private void SubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            if (answered)
            {
                currentQuestionIndex++;
                DisplayCurrentQuestion();
                return;
            }

            int selected = OptionsListBox.SelectedIndex;
            if (selected == -1)
            {
                MessageBox.Show("Please select an answer.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var q = questions[currentQuestionIndex];
            if (selected == q.CorrectIndex)
            {
                score++;
                FeedbackTextBlock.Foreground = Brushes.Green;
                FeedbackTextBlock.Text = $"✅ {q.Explanation}";
            }
            else
            {
                FeedbackTextBlock.Foreground = Brushes.Red;
                FeedbackTextBlock.Text = $"❌ Incorrect. {q.Explanation}";
            }

            answered = true;
        }
    }
}
