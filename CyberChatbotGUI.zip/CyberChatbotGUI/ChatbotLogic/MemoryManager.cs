﻿using System.Collections.Generic;

namespace POE_Part_2_CybersecurityChatbot
{
    public static class MemoryManager
    {
        private static Dictionary<string, string> memory = new Dictionary<string, string>();

        public static void Set(string key, string value)
        {
            memory[key] = value;
        }

        public static string Get(string key)
        {
            return memory.ContainsKey(key) ? memory[key] : null;
        }

        public static bool Contains(string key)
        {
            return memory.ContainsKey(key);
        }
    }
}
