﻿using System;
using System.Windows;

namespace POE_Part_2_CybersecurityChatbot
{
    public static class Utilities
    {
        public static Action<string> OutputAction = null;

        public static void Info(string message)
        {
            if (OutputAction != null)
            {
                OutputAction.Invoke($"🤖 {message}");
                OutputAction.Invoke(""); 
            }
            else
            {
                MessageBox.Show(message); 
            }
        }

        public static void Warn(string message)
        {
            MessageBox.Show($"⚠️ {message}", "Warning");
        }

        public static void Error(string message)
        {
            MessageBox.Show($"❌ {message}", "Error");
        }

        public static string ExtractTopic(string input)
        {
            return input.Replace("i'm interested in", "")
                        .Replace("i am interested in", "")
                        .Trim();
        }
    }
}
