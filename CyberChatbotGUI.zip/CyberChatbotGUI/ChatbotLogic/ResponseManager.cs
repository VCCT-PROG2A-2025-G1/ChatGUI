﻿using System;
using System.Collections.Generic;
using CyberChatbotGUI.Logs;

namespace POE_Part_2_CybersecurityChatbot
{
    public static class ResponseManager
    {
        static string currentTopic = "";

        private static readonly Dictionary<string, string> sentiments = new Dictionary<string, string>
        {
            { "worried", "😟 It’s okay to feel worried. Cybersecurity can be overwhelming, but I’m here to help you step by step." },
            { "anxious", "😟 You're not alone. Let's tackle your cybersecurity questions together." },
            { "frustrated", "😣 I understand. Let's work through your concerns one step at a time." },
            { "curious", "😊 I love your curiosity! Ask me anything about cybersecurity." }
        };

        private static readonly Dictionary<string, List<string>> topics = new Dictionary<string, List<string>>
        {
            { "password", new List<string>{ "🔐 Use strong, unique passwords for each account.", "🔐 Consider using a password manager." } },
            { "scam", new List<string>{ "🚫 Don’t click unknown links.", "🚫 Scammers may impersonate banks—verify before responding." } },
            { "privacy", new List<string>{ "🛡️ Adjust your social media privacy settings.", "🛡️ Use a VPN when using public Wi-Fi." } }
        };

        private static readonly Dictionary<string, Action> keywordActions = new Dictionary<string, Action>
        {
            { "how are you", () => Utilities.Info("😊 I'm just a bot, but I'm happy to help!") },
            { "what can i ask you", () => Utilities.Info("🧠 Ask about: Passwords, Phishing, Privacy, or Safe Browsing.") },
            { "phishing", () => Utilities.Info("🎣 Phishing is a scam to steal your data. Never click on suspicious links.") },
            { "password", () => Utilities.Info("🔐 Use long, strong passwords. Never reuse the same one.") },
            { "vpn", () => Utilities.Info("🛡️ A VPN helps protect your data on unsecured networks.") },
            { "safe browsing", () => Utilities.Info("🌐 Only browse secure HTTPS websites and avoid popups.") },
            { "malware", () => Utilities.Info("🦠 Malware can harm your system. Keep antivirus software updated.") },
            { "social engineering", () => Utilities.Info("🧠 Social engineering tricks you into giving away info. Always verify requests.") },
            { "2fa", () => Utilities.Info("✅ Use 2FA to add a second layer of login security.") },
            { "update", () => Utilities.Info("🔄 Keep all apps and devices updated to patch vulnerabilities.") },
            { "firewall", () => Utilities.Info("🧱 A firewall protects your system from unauthorized access.") },
            { "help", () => Utilities.Info("💡 Try keywords like: phishing, password, 2FA, update, VPN, firewall, malware, privacy.") }
        };

        public static bool TryHandleSentiment(string input)
        {
            foreach (var key in sentiments.Keys)
            {
                if (input.Contains(key))
                {
                    Utilities.Info(sentiments[key]);
                    Logs.Add($"Sentiment detected: {key}");
                    return true;
                }
            }
            return false;
        }

        public static bool TryHandleNLP(string input)
        {
            input = input.ToLower();

            if (input.Contains("remind me to"))
            {
                string task = input.Replace("remind me to", "").Trim();
                if (!string.IsNullOrWhiteSpace(task))
                {
                    string reminderTask = char.ToUpper(task[0]) + task.Substring(1);
                    Utilities.Info($"📌 Reminder set for '{reminderTask}' on tomorrow's date.");
                    Logs.Add($"Reminder created: {reminderTask}");
                }
                else
                {
                    Utilities.Info("⚠️ Please specify what you'd like to be reminded about.");
                }
                return true;
            }

            if (input.Contains("add a task to") || input.Contains("add task to"))
            {
                string task = input.Replace("add a task to", "").Replace("add task to", "").Trim();
                if (!string.IsNullOrWhiteSpace(task))
                {
                    string taskTitle = char.ToUpper(task[0]) + task.Substring(1);
                    Utilities.Info($"📝 Task added: '{taskTitle}'. Would you like to set a reminder?");
                    Logs.Add($"Task added: {taskTitle}");
                }
                else
                {
                    Utilities.Info("⚠️ Please provide a task name.");
                }
                return true;
            }

            if (input.Contains("what have you done for me") || input.Contains("show activity log"))
            {
                var entries = Logs.GetRecentLogs(5);
                Utilities.Info("📄 Recent Activity Log:");
                foreach (var entry in entries)
                {
                    Utilities.Info(entry);
                }
                return true;
            }

            return false;
        }

        public static bool TryHandleInterest(string input)
        {
            if (input.StartsWith("i'm interested in") || input.StartsWith("i am interested in") ||
                input.StartsWith("i want to learn about") || input.StartsWith("i would like info on"))
            {
                var topic = Utilities.ExtractTopic(input);
                if (!string.IsNullOrWhiteSpace(topic))
                {
                    MemoryManager.Set("interest", topic);
                    currentTopic = topic;
                    Utilities.Info($"📌 Got it — you're interested in {topic}. Let's dive in.");
                    Logs.Add($"User showed interest in: {topic}");
                }
                return true;
            }

            if ((input.Contains("any tips") || input.Contains("give me tips") || input.Contains("tips please")) &&
                MemoryManager.Contains("interest"))
            {
                string interest = MemoryManager.Get("interest");
                Utilities.Info($"💡 Here's a tip on {interest}:");
                Logs.Add($"User requested tip on interest: {interest}");
                ShowRandomTip(interest);
                return true;
            }

            return false;
        }

        public static bool TryHandleTopicFollowUp(string input)
        {
            string[] followUpPhrases = {
                "tell me more", "another tip", "give me another", "more info",
                "expand", "explain more", "what else", "explain further", "anything else"
            };

            foreach (var phrase in followUpPhrases)
            {
                if (input.Contains(phrase) && !string.IsNullOrEmpty(currentTopic))
                {
                    ShowRandomTip(currentTopic);
                    Logs.Add($"User asked for more info on topic: {currentTopic} (via '{phrase}')");
                    return true;
                }
            }
            return false;
        }

        public static bool TryHandleKeyword(string input)
        {
            input = input.ToLower();
            foreach (var key in keywordActions.Keys)
            {
                if (input.Contains(key))
                {
                    keywordActions[key]();
                    return true;
                }
            }
            return false;
        }

        public static void ShowRandomTip(string topic)
        {
            if (topics.ContainsKey(topic))
            {
                var tips = topics[topic];
                var tip = tips[new Random().Next(tips.Count)];
                Utilities.Info(tip);
                Logs.Add($"Displayed tip on topic: {topic}");
            }
            else
            {
                Utilities.Info("⚠️ Sorry, I don't have tips on that topic.");
                Logs.Add($"No tips found for topic: {topic}");
            }
        }
    }
}