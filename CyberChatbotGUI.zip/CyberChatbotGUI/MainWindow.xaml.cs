﻿// Morné Viljoen
// ST10374994
// Group 1
// Link for p3: https://youtu.be/kpwPWvDzBTc
// References: 
//OpenAI (2025). ChatGPT. [online] ChatGPT. Available at: https://chatgpt.com/.


using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using CyberChatbotGUI.QuizQuestion;
using static CyberChatbotGUI.Logs.Logs;
using POE_Part_2_CybersecurityChatbot;

namespace CyberChatbotGUI
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<CyberTask> Tasks = new ObservableCollection<CyberTask>();
        private DispatcherTimer reminderTimer;

        public MainWindow()
        {
            InitializeComponent();
            TaskListBox.ItemsSource = Tasks;
            StartReminderTimer();

            Utilities.OutputAction = (msg) => ChatListBox.Items.Add(msg);
            ShowGreeting();
        }

        private void ShowGreeting()
        {
            ChatListBox.Items.Add("🤖 Hello! I'm your Cybersecurity Chatbot.");
            ChatListBox.Items.Add("You can ask me about passwords, phishing, scams, or online safety.");
            ChatListBox.Items.Add("Feeling something? I understand if you're anxious or frustrated.");
            ChatListBox.Items.Add("Try typing: 'I'm curious about passwords' or 'Any tips for me?'");
            ChatListBox.Items.Add("---------------------------------------------");
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TaskTitleBox.Text) || string.IsNullOrWhiteSpace(TaskDescBox.Text))
            {
                MessageBox.Show("Please enter both a task title and description.", "Missing Info", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var task = new CyberTask
            {
                Title = TaskTitleBox.Text,
                Description = TaskDescBox.Text,
                ReminderDate = ReminderPicker.SelectedDate,
                IsCompleted = false
            };

            Tasks.Add(task);
            Add($"Task added: '{task.Title}'");

            MessageBox.Show($"Bot: Task added with the description \"{task.Description}\". Would you like a reminder?", "Chatbot", MessageBoxButton.OK, MessageBoxImage.Information);

            if (task.ReminderDate.HasValue)
            {
                int daysUntil = (task.ReminderDate.Value - DateTime.Today).Days;
                Add($"Reminder set for '{task.Title}' in {daysUntil} day(s)");
                MessageBox.Show($"User: Yes, remind me in {daysUntil} day(s).\nBot: Got it! I'll remind you in {daysUntil} day(s).", "Chatbot", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            TaskTitleBox.Text = string.Empty;
            TaskDescBox.Text = string.Empty;
            ReminderPicker.SelectedDate = null;
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button?.Tag is CyberTask task)
            {
                var result = MessageBox.Show($"Are you sure you want to delete the task \"{task.Title}\"?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    Tasks.Remove(task);
                    Add($"Task deleted: '{task.Title}'");
                    MessageBox.Show($"Bot: Task \"{task.Title}\" has been deleted.", "Chatbot", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void StartReminderTimer()
        {
            reminderTimer = new DispatcherTimer();
            reminderTimer.Interval = TimeSpan.FromSeconds(10);
            reminderTimer.Tick += ReminderTimer_Tick;
            reminderTimer.Start();
        }

        private void ReminderTimer_Tick(object sender, EventArgs e)
        {
            foreach (var task in Tasks)
            {
                if (task.ReminderDate.HasValue &&
                    task.ReminderDate.Value.Date == DateTime.Today &&
                    !task.IsCompleted)
                {
                    MessageBox.Show($"🔔 Reminder: {task.Title}\n{task.Description}", "Chatbot Reminder", MessageBoxButton.OK, MessageBoxImage.Information);
                    Add($"Reminder triggered for: '{task.Title}'");
                }
            }
        }

        private void StartQuiz_Click(object sender, RoutedEventArgs e)
        {
            Add("Quiz started.");
            var quizWindow = new QuizWindow();
            quizWindow.ShowDialog();
            Add("Quiz completed.");
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string input = UserInputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            ChatListBox.Items.Add($"You: {input}");

            if (ResponseManager.TryHandleSentiment(input.ToLower())) return;
            if (ResponseManager.TryHandleInterest(input.ToLower())) return;
            if (ResponseManager.TryHandleTopicFollowUp(input.ToLower())) return;
            if (ResponseManager.TryHandleKeyword(input.ToLower())) return;

            if (ResponseManager.TryHandleNLP(input.ToLower()))
            {
                Add($"NLP interpreted input: '{input}'");
                return;
            }

            Utilities.Info("Sorry, I’m not sure how to respond to that. Try asking about phishing, passwords, or privacy.");
        }

        private void ShowLog_Click(object sender, RoutedEventArgs e)
        {
            var logs = GetRecentLogs(10);
            string message = "📜 Recent Activity:\n\n" + string.Join("\n", logs);
            MessageBox.Show(message, "Activity Log", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
